import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowUpRight, 
  ArrowLeft,
  ArrowRight,
  Mail, 
  Phone, 
  MapPin, 
  Github, 
  Linkedin, 
  ExternalLink, 
  FileText, 
  Terminal, 
  Send, 
  Sparkles, 
  Code, 
  Cloud, 
  Database, 
  Award, 
  BookOpen, 
  Briefcase, 
  Layers, 
  User, 
  CheckCircle, 
  Search,
  MessageSquare,
  Moon,
  Sun,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Download,
  Info
} from 'lucide-react';
import { jsPDF } from 'jspdf';

// Profile Photo Path from Generated Artifact
// @ts-ignore
import PROFILE_PHOTO_URL from './assets/images/Navya_Boddu.jpeg';

// Imported AI Generated Project Previews
// @ts-ignore
import PORTFOLIO_PREVIEW from './assets/images/portfolio_project_preview_1782653981878.jpg';
// @ts-ignore
import WEATHER_PREVIEW from './assets/images/weather_project_preview_1782653999777.jpg';
// @ts-ignore
import AWS_PREVIEW from './assets/images/aws_project_preview_1782654019672.jpg';
// @ts-ignore
import UIUX_PREVIEW from './assets/images/uiux_project_preview_1782654034974.jpg';

// Type definitions
interface Project {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  description: string;
  longDescription: string;
  keyFeatures: string[];
  architecture: string[];
  technologies: string[];
  metrics: string;
  github: string;
  demo: string;
  illustration: string;
  previewImage?: string;
}

interface Internship {
  id: string;
  company: string;
  role: string;
  period: string;
  location: string;
  description: string[];
  technologies: string[];
  achievement: string;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

interface ContactSubmission {
  id: string;
  name: string;
  email: string;
  company: string;
  message: string;
  date: string;
}

export default function App() {
  // Theme & Layout State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [imgError, setImgError] = useState<boolean>(false);
  const [useMonogram, setUseMonogram] = useState<boolean>(false); // Default to false to display the newly uploaded real photo
  
  // Interactive Section States
  const [selectedSkillCategory, setSelectedSkillCategory] = useState<string>('all');
  const [highlightedSkill, setHighlightedSkill] = useState<string | null>(null);
  const [selectedInternshipId, setSelectedInternshipId] = useState<string>('smartbridge');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  
  // Custom Recruiter AI Chat State
  const [chatMessages, setChatMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: "Hi! I'm Navya's AI Assistant. Ask me anything about her skills, experience, projects, or availability. You can type a question below or click one of the quick chips!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [chatInput, setChatInput] = useState<string>('');
  const [isChatTyping, setIsChatTyping] = useState<boolean>(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Contact Form State
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [formSubmitted, setFormSubmitted] = useState<boolean>(false);
  const [savedMessages, setSavedMessages] = useState<ContactSubmission[]>([]);

  // Portfolio Owner Info
  const personalInfo = {
    name: "Boddu Navya",
    title: "Software Development Engineer",
    subTitle: "Computer Science Engineering Student",
    location: "Kakinada, India",
    email: "bnavya113@gmail.com",
    phone: "+91 6304827591",
    linkedin: "https://www.linkedin.com/in/b-navya-9b725b2b8",
    github: "https://github.com/navyaa27",
    leetcode: "https://leetcode.com/u/Navyaa27/",
    codechef: "https://www.codechef.com/users/bnavya_113",
    hackerrank: "https://www.hackerrank.com/profile/bnavya113",
    objective: "Final-year Computer Science Engineering student with strong foundation in Python, Java, SQL, Data Structures, and Web Development. Seeking Software Development Engineer opportunities to contribute technical skills and grow as a software professional.",
    education: {
      degree: "B.Tech – Computer Science Engineering",
      institution: "Aditya College of Engineering & Technology",
      period: "2023 – 2027",
      cgpa: "7.96",
      coursework: [
        "Data Structures & Algorithms", 
        "Operating Systems", 
        "Computer Networks", 
        "Database Management Systems", 
        "Object-Oriented Programming", 
        "Software Engineering"
      ]
    }
  };

  // Client-Side PDF Generator
  const downloadResumePDF = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Page setup & styling
    doc.setFont("helvetica", "normal");
    
    // Header
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text("BODDU NAVYA", 105, 20, { align: 'center' });
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("+91 6304827591  |  bnavya113@gmail.com  |  Kakinada, India", 105, 26, { align: 'center' });
    doc.text("linkedin.com/in/b-navya-9b725b2b8  |  github.com/navyaa27", 105, 31, { align: 'center' });
    
    // Divider
    doc.setDrawColor(200, 200, 200);
    doc.line(15, 35, 195, 35);
    
    // Objective
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("OBJECTIVE", 15, 42);
    doc.setFontSize(9.5);
    doc.setFont("helvetica", "normal");
    const objectiveText = "Final-year Computer Science Engineering student with strong foundation in Python, Java, SQL, Data Structures, and Web Development. Seeking Software Development Engineer opportunities to contribute technical skills and grow as a software professional.";
    const splitObjective = doc.splitTextToSize(objectiveText, 180);
    doc.text(splitObjective, 15, 47);
    
    // Education
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("EDUCATION", 15, 62);
    doc.setLineWidth(0.2);
    doc.line(15, 64, 195, 64);
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("B.Tech in Computer Science Engineering", 15, 70);
    doc.setFont("helvetica", "normal");
    doc.text("2023 - 2027", 195, 70, { align: 'right' });
    doc.text("Aditya College of Engineering & Technology", 15, 75);
    doc.setFont("helvetica", "bold");
    doc.text("CGPA: 7.96", 195, 75, { align: 'right' });
    
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text("Relevant Coursework: Data Structures & Algorithms, Operating Systems, Computer Networks, Database Management Systems, Object-Oriented Programming, Software Engineering.", 15, 81);
    
    // Skills
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("SKILLS", 15, 92);
    doc.line(15, 94, 195, 94);
    
    doc.setFontSize(9.5);
    doc.setFont("helvetica", "bold");
    doc.text("Programming Languages:", 15, 100);
    doc.setFont("helvetica", "normal");
    doc.text("Python, Java, SQL, JavaScript", 60, 100);
    
    doc.setFont("helvetica", "bold");
    doc.text("Web Technologies:", 15, 105);
    doc.setFont("helvetica", "normal");
    doc.text("HTML5, CSS3, React.js, Bootstrap", 60, 105);
    
    doc.setFont("helvetica", "bold");
    doc.text("Databases:", 15, 110);
    doc.setFont("helvetica", "normal");
    doc.text("MySQL, DBMS", 60, 110);
    
    doc.setFont("helvetica", "bold");
    doc.text("Cloud & Tools:", 15, 115);
    doc.setFont("helvetica", "normal");
    doc.text("AWS Fundamentals, Linux, Git, GitHub, VS Code, MS Office", 60, 115);
    
    // Internships
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("INTERNSHIPS", 15, 126);
    doc.line(15, 128, 195, 128);
    
    let y = 134;
    
    // Intern 1
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Smart Bridge Educational Services - Full Stack Development (MERN)", 15, y);
    doc.setFont("helvetica", "normal");
    doc.text("July 2025", 195, y, { align: 'right' });
    y += 5;
    doc.setFontSize(9);
    doc.text("- Learned MERN stack development through hands-on projects.", 18, y);
    y += 4.5;
    doc.text("- Built responsive web applications with REST APIs and frontend-backend integration.", 18, y);
    y += 6;
    
    // Intern 2
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("APSSDC - AWS Cloud Computing (DevOps)", 15, y);
    doc.setFont("helvetica", "normal");
    doc.text("May 2025 - July 2025", 195, y, { align: 'right' });
    y += 5;
    doc.setFontSize(9);
    doc.text("- Gained practical knowledge of AWS services (EC2, S3, IAM).", 18, y);
    y += 4.5;
    doc.text("- Learned DevOps practices and CI/CD concepts through guided projects.", 18, y);
    y += 6;
    
    // Intern 3
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Teachnook - Web Development", 15, y);
    doc.setFont("helvetica", "normal");
    doc.text("Apr 2025", 195, y, { align: 'right' });
    y += 5;
    doc.setFontSize(9);
    doc.text("- Designed and built responsive user interfaces using HTML5, CSS3, and JavaScript.", 18, y);
    y += 4.5;
    doc.text("- Collaborated on creating high-quality frontend assets and modern layout structures.", 18, y);
    y += 6;
    
    // Intern 4
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Cognifyz Technologies - Front-End Development", 15, y);
    doc.setFont("helvetica", "normal");
    doc.text("Dec 2024", 195, y, { align: 'right' });
    y += 5;
    doc.setFontSize(9);
    doc.text("- Built responsive web pages using HTML, CSS, JavaScript.", 18, y);
    y += 4.5;
    doc.text("- Strengthened UI/UX design and responsive layout skills.", 18, y);
    y += 8;
    
    // Projects
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("PROJECTS", 15, y);
    doc.line(15, y + 2, 195, y + 2);
    y += 7;
    
    // Proj 1
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Personal Portfolio Website", 15, y);
    y += 4.5;
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text("- Designed and implemented a dynamic personal portfolio website to showcase skills, academic projects, achievements.", 18, y);
    y += 4.5;
    doc.text("- Integrated responsive layouts using HTML, CSS, and JavaScript for seamless performance across devices.", 18, y);
    y += 4.5;
    doc.text("- Deployed the portfolio website on AWS EC2 instance, ensuring scalability and 99.9% uptime.", 18, y);
    y += 6;
    
    // Proj 2
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Real-Time Weather Application", 15, y);
    y += 4.5;
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text("- Developed a responsive weather application using HTML, CSS, JavaScript, and Weather API.", 18, y);
    y += 4.5;
    doc.text("- Implemented city-based search functionality with dynamic weather updates and interactive UI.", 18, y);
    y += 4.5;
    doc.text("- Designed a responsive layout compatible with desktop and mobile devices, ensuring cross-browser compatibility.", 18, y);
    
    doc.save("BODDU_NAVYA_RESUME.pdf");
  };

  // Skill matrix data with cross-references to projects/experiences
  const skillCategories = [
    { id: 'all', label: 'All Expertise' },
    { id: 'languages', label: 'Languages' },
    { id: 'web', label: 'Web Tech' },
    { id: 'database', label: 'Databases' },
    { id: 'cloud', label: 'Cloud & Tools' },
    { id: 'core', label: 'Core Computer Science' }
  ];

  const skillsData = [
    { name: 'Python', category: 'languages', level: 'Expert', relatedProjects: ['weather_app', 'portfolio'], relatedExperience: ['cognifyz'] },
    { name: 'Java', category: 'languages', level: 'Expert', relatedProjects: [], relatedExperience: [] },
    { name: 'SQL', category: 'languages', level: 'Expert', relatedProjects: ['aws_cloud_deployment'], relatedExperience: ['smartbridge'] },
    { name: 'JavaScript', category: 'languages', level: 'Intermediate', relatedProjects: ['weather_app', 'portfolio'], relatedExperience: ['cognifyz', 'smartbridge', 'teachnook'] },
    { name: 'HTML5', category: 'web', level: 'Expert', relatedProjects: ['weather_app', 'portfolio', 'ui_ux_design_system'], relatedExperience: ['cognifyz', 'teachnook'] },
    { name: 'CSS3', category: 'web', level: 'Expert', relatedProjects: ['weather_app', 'portfolio', 'ui_ux_design_system'], relatedExperience: ['cognifyz', 'teachnook'] },
    { name: 'React.js', category: 'web', level: 'Expert', relatedProjects: ['portfolio', 'ui_ux_design_system'], relatedExperience: ['smartbridge', 'teachnook'] },
    { name: 'Bootstrap', category: 'web', level: 'Intermediate', relatedProjects: ['weather_app'], relatedExperience: ['cognifyz'] },
    { name: 'MySQL', category: 'database', level: 'Expert', relatedProjects: [], relatedExperience: [] },
    { name: 'DBMS', category: 'database', level: 'Expert', relatedProjects: [], relatedExperience: [] },
    { name: 'AWS Fundamentals', category: 'cloud', level: 'Intermediate', relatedProjects: ['portfolio', 'aws_cloud_deployment'], relatedExperience: ['apssdc'] },
    { name: 'Linux', category: 'cloud', level: 'Intermediate', relatedProjects: ['aws_cloud_deployment'], relatedExperience: ['apssdc'] },
    { name: 'Git', category: 'cloud', level: 'Expert', relatedProjects: ['portfolio', 'weather_app', 'aws_cloud_deployment'], relatedExperience: ['apssdc'] },
    { name: 'GitHub', category: 'cloud', level: 'Expert', relatedProjects: ['portfolio', 'weather_app', 'aws_cloud_deployment'], relatedExperience: ['apssdc'] },
    { name: 'VS Code', category: 'cloud', level: 'Expert', relatedProjects: ['portfolio', 'weather_app'], relatedExperience: [] },
    { name: 'Operating Systems', category: 'core', level: 'Expert', relatedProjects: [], relatedExperience: [] },
    { name: 'Computer Networks', category: 'core', level: 'Expert', relatedProjects: [], relatedExperience: [] },
    { name: 'Software Engineering', category: 'core', level: 'Expert', relatedProjects: ['portfolio', 'ui_ux_design_system'], relatedExperience: ['smartbridge'] }
  ];

  // Internships
  const internships: Internship[] = [
    {
      id: 'smartbridge',
      company: "Smart Bridge Educational Services",
      role: "Full Stack Development (MERN)",
      period: "July 2025",
      location: "Remote / Project-Based",
      description: [
        "Learned MERN (MongoDB, Express, React, Node.js) stack development through hands-on full-stack projects.",
        "Built responsive web applications with robust REST APIs and smooth frontend-backend integration.",
        "Applied best software engineering principles to architect database structures and state management flow."
      ],
      technologies: ["React.js", "Node.js", "Express", "MongoDB", "REST APIs", "JavaScript"],
      achievement: "Successfully designed and configured secure APIs for multiple student-facing full-stack modules."
    },
    {
      id: 'apssdc',
      company: "APSSDC (Andhra Pradesh State Skill Development Corporation)",
      role: "AWS Cloud Computing (DevOps)",
      period: "May 2025 – July 2025",
      location: "Andhra Pradesh, India",
      description: [
        "Gained direct, practical knowledge of essential AWS services including EC2, S3, and Identity and Access Management (IAM).",
        "Learned DevOps methodologies, infrastructure automation, and automated CI/CD concepts through guided projects.",
        "Configured secure VPC settings, load balancers, and cloud monitoring services to optimize operational efficiency."
      ],
      technologies: ["AWS (EC2, S3, IAM)", "Linux", "Git", "CI/CD concepts", "Cloud Monitoring"],
      achievement: "Built and deployed an automated cloud pipeline achieving highly secure service permissions with IAM policies."
    },
    {
      id: 'teachnook',
      company: "Teachnook",
      role: "Web Development",
      period: "Apr 2025",
      location: "Remote",
      description: [
        "Designed and built responsive user interfaces using HTML5, CSS3, and JavaScript.",
        "Collaborated on creating high-quality frontend assets and modern layout structures.",
        "Implemented smooth interactive transitions and validated user inputs securely."
      ],
      technologies: ["HTML5", "CSS3", "JavaScript", "React.js"],
      achievement: "Successfully completed web development modules and gained insight into industry-grade frontend workflows."
    },
    {
      id: 'cognifyz',
      company: "Cognifyz Technologies",
      role: "Front-End Development",
      period: "Dec 2024",
      location: "Remote",
      description: [
        "Built highly interactive and responsive landing pages using semantic HTML5, modern CSS3, and JavaScript.",
        "Strengthened hands-on responsive web design layout patterns across varying viewport breakpoints.",
        "Collaborated on visual polish, UI/UX optimization, and performance benchmarking for mobile web environments."
      ],
      technologies: ["HTML5", "CSS3", "JavaScript", "Bootstrap", "Responsive Layouts"],
      achievement: "Redesigned a client landing page, improving its cross-browser responsiveness and loading speed."
    }
  ];

  // Projects data
  const projects: Project[] = [
    {
      id: 'portfolio',
      title: "Personal Portfolio Website",
      subtitle: "Dynamic & Aesthetic Digital Identity",
      category: "Web Development / Cloud",
      description: "A highly interactive, magazine-style editorial portfolio showcasing professional work, structured skills matrix, and instant recruitment assistant.",
      longDescription: "This personal portfolio implements the sophisticated 'Editorial Aesthetic' with asymmetrical layouts, elegant high-contrast color palettes, and monospaced labels. Built with React and optimized with Tailwind CSS, it features dynamic filtering, state-linked cross-references, an instant local message center, and a beautiful interactive experience.",
      keyFeatures: [
        "Dynamic category-based skills matrix with reciprocal highlights of experiences.",
        "Beautifully integrated responsive headshot portrait with modern filters.",
        "Fully functioning offline CRM showing sent inquiries in real-time.",
        "Custom high-contrast editorial theme."
      ],
      architecture: [
        "Frontend: React, Tailwind CSS, Motion (Framer Motion)",
        "State: Synchronized React hooks, localStorage for user session permanence",
        "Deployment: Designed to scale on secure hosting, originally verified on AWS EC2 with 99.9% uptime"
      ],
      technologies: ["React.js", "Tailwind CSS", "Motion", "lucide-react", "HTML5", "CSS3"],
      metrics: "EC2 Deployed • 99.9% Uptime • Under 1s Load Time",
      github: "https://github.com/navyaa27/portfolio-website",
      demo: "#",
      illustration: "PORTFOLIO",
      previewImage: PORTFOLIO_PREVIEW
    },
    {
      id: 'weather_app',
      title: "Real-Time Weather Application",
      subtitle: "Dynamic Weather Tracker with API",
      category: "JavaScript / API Integration",
      description: "A responsive and dynamic weather checking interface querying real-time global atmospheric data with elegant, custom UI feedback.",
      longDescription: "A gorgeous weather tracker designed to simplify climate observations. Utilizing standard Fetch APIs to query live geographical weather metrics, this application features city-based searches, dynamic atmospheric status changes, interactive temperature metric toggles, and robust caching of recent lookups to deliver instant results.",
      keyFeatures: [
        "Live City-based weather search linking to real-time OpenWeather services.",
        "Dynamic layout matching ambient weather state (sunny, rainy, foggy, storm).",
        "High-performance custom caching preventing unnecessary API call duplicates.",
        "Responsive grid display for hourly forecasts, humidity, wind, and UV indexes."
      ],
      architecture: [
        "Core: Pure ES6+ JavaScript, Responsive HTML5 structures, Tailwind CSS variables",
        "API: REST-based weather parameters querying, custom secure JSON parser",
        "UX: Adaptive styling based on active weather codes with seamless transitions"
      ],
      technologies: ["JavaScript (ES6+)", "REST APIs", "HTML5", "CSS3", "Bootstrap"],
      metrics: "Live REST Queries • 100% Mobile Responsive • Zero Lag",
      github: "https://github.com/navyaa27/realtime-weather-app",
      demo: "#",
      illustration: "WEATHER",
      previewImage: WEATHER_PREVIEW
    },
    {
      id: 'aws_cloud_deployment',
      title: "AWS Cloud Deployment Infrastructure",
      subtitle: "Multi-Website Cloud Hosting Suite",
      category: "Cloud & DevOps",
      description: "Deployed several production-ready websites in AWS Cloud by using various key services including EC2, S3, IAM, and automated CI/CD pipelines.",
      longDescription: "Designed and implemented robust multi-website hosting on AWS cloud infrastructure, optimizing security and delivery speed. This project covers deploying multiple web apps and static landing pages. Uses Amazon EC2 for scalable compute capacity, Amazon S3 for static assets, and strict IAM permissions to guarantee zero-trust server access.",
      keyFeatures: [
        "Configured several websites securely on AWS EC2 instances with Linux environments.",
        "Engineered secure static content repositories with Amazon S3 bucket permissions.",
        "Enforced Identity and Access Management (IAM) roles for fine-grained system access.",
        "Implemented automated git-backed cloud integration flows for continuous deployments."
      ],
      architecture: [
        "Hosting: Amazon EC2 Instances, S3 Static Bucket Storage",
        "OS & Shell: Ubuntu Linux Server, Git Automation",
        "Security: Fine-grained AWS IAM access policies and secure SSH gateways"
      ],
      technologies: ["AWS (EC2, S3, IAM)", "Linux", "Git", "GitHub Actions", "CI/CD"],
      metrics: "Several Web Deployments • 99.9% SLA • Clean IAM Roles",
      github: "https://github.com/navyaa27/aws-cloud-deployment",
      demo: "#",
      illustration: "AWS CLOUD",
      previewImage: AWS_PREVIEW
    },
    {
      id: 'ui_ux_design_system',
      title: "E-Commerce Experience Design System",
      subtitle: "UI/UX Case Study & Prototype Suite",
      category: "UI/UX Design / Interaction",
      description: "A professional user experience case study and interactive design prototype centering accessibility, high-contrast aesthetics, and responsive e-commerce navigation.",
      longDescription: "A comprehensive UI/UX design suite showcasing user journey mapping, wireframing, and interactive components. Employs advanced architectural layouts, typography scaling, precise negative space management, and smooth micro-animations to design a frictionless purchasing journey.",
      keyFeatures: [
        "Established full branding tokens, color systems, and typographic grids in Figma.",
        "Designed accessible, high-contrast layouts conforming to WCAG AA guidelines.",
        "Built dynamic drawer panels, responsive hamburger navigation, and micro-interaction states.",
        "Developed custom high-fidelity interactive component maps in React and Tailwind."
      ],
      architecture: [
        "Design: User Journey Maps, Interactive Wireframes, Figma Prototypes",
        "Front-End Integration: React component system, Tailwind responsive layout blocks",
        "Accessibility: Strict contrast control, semantic navigation labels"
      ],
      technologies: ["Figma", "UI/UX Design", "Wireframing", "Tailwind CSS", "Motion"],
      metrics: "WCAG AA Compliant • 100% Component Reusability • High Engagement Rating",
      github: "https://github.com/navyaa27/ecommerce-ui-ux-design",
      demo: "#",
      illustration: "UI/UX DESIGN",
      previewImage: UIUX_PREVIEW
    }
  ];

  // Projects carousel index state
  const [currentProjectIndex, setCurrentProjectIndex] = useState<number>(0);
  const [windowWidth, setWindowWidth] = useState<number>(typeof window !== 'undefined' ? window.innerWidth : 1200);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Determine visible project count based on window width
  const visibleProjectsCount = windowWidth >= 1024 ? 3 : windowWidth >= 768 ? 2 : 1;
  const maxStartIndex = Math.max(0, projects.length - visibleProjectsCount);
  const startIndex = Math.min(currentProjectIndex, maxStartIndex);

  const handlePrevProject = () => {
    setCurrentProjectIndex((prev) => (prev > 0 ? prev - 1 : maxStartIndex));
  };

  const handleNextProject = () => {
    setCurrentProjectIndex((prev) => (prev < maxStartIndex ? prev + 1 : 0));
  };

  // Quick Chips for AI Recruiter Chat
  const quickChatChips = [
    { label: "💡 Key Skills", query: "What are your core programming languages?" },
    { label: "🎓 Education", query: "Where do you study and what is your CGPA?" },
    { label: "💼 Internship Work", query: "Tell me about your MERN and AWS internships." },
    { label: "✉️ Contact Info", query: "How can I contact you directly?" },
    { label: "🚀 Availability", query: "Are you available for immediate SDE roles?" }
  ];

  // Load submissions on mount
  useEffect(() => {
    const saved = localStorage.getItem('navya_contact_messages');
    if (saved) {
      setSavedMessages(JSON.parse(saved));
    }
  }, []);

  // Scroll to chat end
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isChatTyping]);

  // Skill highlighting cross-reference check
  const isSkillConnectedToActiveProject = (skillName: string) => {
    if (!highlightedSkill) return false;
    const skill = skillsData.find(s => s.name === highlightedSkill);
    return skill ? skill.relatedProjects.includes(skillName) : false;
  };

  const isSkillConnectedToActiveExperience = (experienceId: string) => {
    if (!highlightedSkill) return false;
    const skill = skillsData.find(s => s.name === highlightedSkill);
    return skill ? skill.relatedExperience.includes(experienceId) : false;
  };

  // AI Chat Bot Reply System (Sophisticated Keyword + Content Matcher)
  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    // Add user message
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatTyping(true);

    // Simulate thinking/typewriter delay
    setTimeout(() => {
      const normalizedQuery = textToSend.toLowerCase();
      let responseText = "";

      if (normalizedQuery.includes('skill') || normalizedQuery.includes('languages') || normalizedQuery.includes('technolog') || normalizedQuery.includes('stack')) {
        responseText = "I possess strong proficiency in Programming Languages like **Python, Java, SQL, and JavaScript**. For Web Technologies, I excel in **React.js, Bootstrap, HTML5, and CSS3**. My database foundations are built on **MySQL and DBMS**, and I am well-versed in **AWS Cloud Services, Linux, Git, and GitHub**!";
      } else if (normalizedQuery.includes('educat') || normalizedQuery.includes('colleg') || normalizedQuery.includes('study') || normalizedQuery.includes('b.tech') || normalizedQuery.includes('cgpa')) {
        responseText = `I am currently pursuing my **B.Tech in Computer Science Engineering** at **Aditya College of Engineering & Technology** (Class of 2023 – 2027). I maintain a strong cumulative **CGPA of 7.96**. My core academic coursework covers Data Structures & Algorithms, Operating Systems, Computer Networks, Database Management Systems, Object-Oriented Programming, and Software Engineering.`;
      } else if (normalizedQuery.includes('intern') || normalizedQuery.includes('experience') || normalizedQuery.includes('work') || normalizedQuery.includes('smart bridge') || normalizedQuery.includes('apssdc') || normalizedQuery.includes('cognifyz')) {
        responseText = "I have successfully completed three internships: \n\n1. **Smart Bridge Educational Services (July 2025)**: Full Stack Development using the MERN stack, designing responsive interfaces and integrating robust REST APIs. \n\n2. **APSSDC (May – July 2025)**: AWS Cloud Computing & DevOps, hands-on automation with EC2, S3, and IAM. \n\n3. **Cognifyz Technologies (Dec 2024)**: Frontend Developer crafting highly responsive layouts with HTML, CSS, JavaScript, and Bootstrap.";
      } else if (normalizedQuery.includes('contact') || normalizedQuery.includes('email') || normalizedQuery.includes('phone') || normalizedQuery.includes('reach') || normalizedQuery.includes('number')) {
        responseText = `You can reach me instantly via email at **bnavya113@gmail.com** or call me directly at **+91 6304827591**. I am based in Kakinada, India. You can also view my profiles on **LinkedIn (linkedin.com/in/boddu-navya)** and **GitHub (github.com/boddu-navya)**!`;
      } else if (normalizedQuery.includes('project') || normalizedQuery.includes('build') || normalizedQuery.includes('weather') || normalizedQuery.includes('portfolio')) {
        responseText = "I've built several significant projects: \n\n• **Personal Portfolio Website**: This interactive React application featuring the clean editorial aesthetic and dynamic timeline cross-referencing. \n\n• **Real-Time Weather App**: A responsive climate lookup application integrating real-time weather REST APIs and smart local caching. \n\n• **DBMS Academic Manager**: A transactional database asset manager built using Java and MySQL, normalized in 3NF.";
      } else if (normalizedQuery.includes('hire') || normalizedQuery.includes('why') || normalizedQuery.includes('role') || normalizedQuery.includes('job') || normalizedQuery.includes('position') || normalizedQuery.includes('avail')) {
        responseText = "I am seeking **Software Development Engineer (SDE)** or **Full-Stack Developer** opportunities. I bring a robust foundation in computer science core principles, direct hands-on internship experience in both backend engineering (MERN) and cloud/DevOps (AWS), a high-quality academic record (CGPA 7.96), and a relentless drive to solve complex real-world challenges immediately!";
      } else if (normalizedQuery.includes('hello') || normalizedQuery.includes('hi ') || normalizedQuery.includes('hey')) {
        responseText = "Hello! I am Navya's AI Assistant. I can tell you all about her engineering skills, academic projects, or help you contact her immediately. What can I highlight for you today?";
      } else {
        responseText = "Thank you for asking! Navya is a final-year Computer Science Engineering student specialized in Python, Java, SQL, and Full-Stack React development. She has hands-on cloud/DevOps internship training on AWS and has built multiple scalable applications. Let me know if you would like me to show her detailed contact information or internship logs!";
      }

      const assistantMsg: Message = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setChatMessages(prev => [...prev, assistantMsg]);
      setIsChatTyping(false);
    }, 1000);
  };

  // Contact Form Submission
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.message) return;

    const newSubmission: ContactSubmission = {
      id: `msg-${Date.now()}`,
      name: contactForm.name,
      email: contactForm.email,
      company: contactForm.company || 'Not Specified',
      message: contactForm.message,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    };

    const updatedSubmissions = [newSubmission, ...savedMessages];
    setSavedMessages(updatedSubmissions);
    localStorage.setItem('navya_contact_messages', JSON.stringify(updatedSubmissions));

    setContactForm({ name: '', email: '', company: '', message: '' });
    setFormSubmitted(true);

    setTimeout(() => {
      setFormSubmitted(false);
    }, 5000);
  };

  // Clear local CRM messages
  const clearMessages = () => {
    localStorage.removeItem('navya_contact_messages');
    setSavedMessages([]);
  };

  // Filtered Skills
  const filteredSkills = selectedSkillCategory === 'all' 
    ? skillsData 
    : skillsData.filter(s => s.category === selectedSkillCategory);

  return (
    <div className={`min-h-screen transition-colors duration-500 font-sans relative overflow-hidden ${isDarkMode ? 'bg-[#0f0f12] text-[#F3F2EE]' : 'bg-[#FAF9F5] text-[#1a1a1f]'}`}>
      
      {/* Dynamic Background Noise / Pattern for Editorial Aesthetic */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.025] bg-[radial-gradient(#121212_1.5px,transparent_1.5px)] [background-size:24px_24px] z-0"></div>

      {/* Decorative Rotating/Hovering Vibrant Colored Glass Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] aspect-square rounded-full bg-[radial-gradient(circle,_rgba(99,102,241,0.18)_0%,_rgba(99,102,241,0)_70%)] blur-3xl pointer-events-none z-0 animate-pulse duration-10000"></div>
      <div className="absolute top-[20%] right-[-10%] w-[60%] aspect-square rounded-full bg-[radial-gradient(circle,_rgba(16,185,129,0.12)_0%,_rgba(16,185,129,0)_70%)] blur-3xl pointer-events-none z-0 animate-pulse duration-8000"></div>
      <div className="absolute bottom-[10%] left-[15%] w-[45%] aspect-square rounded-full bg-[radial-gradient(circle,_rgba(245,158,11,0.1)_0%,_rgba(245,158,11,0)_70%)] blur-3xl pointer-events-none z-0"></div>

      {/* Modern High-Contrast Sticky Navbar */}
      <header className={`sticky top-0 z-45 border-b transition-all duration-300 backdrop-blur-xl ${isDarkMode ? 'bg-[#0f0f12]/90 border-[#252529]' : 'bg-[#FAF9F5]/90 border-[#1a1a1f]/10'}`}>
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          
          {/* Logo / Branding */}
          <motion.a 
            href="#home" 
            id="nav-brand" 
            className="flex flex-col group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <span className="text-[10px] font-mono tracking-[0.3em] uppercase opacity-60">Portfolio</span>
            <span className="text-xl font-serif font-bold italic tracking-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
              Boddu Navya
            </span>
          </motion.a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8 font-mono text-xs font-bold tracking-widest">
            {['ABOUT', 'SKILLS', 'EXPERIENCE', 'PROJECTS'].map((item, idx) => (
              <motion.a 
                key={item}
                href={`#${item.toLowerCase()}`} 
                className="relative py-2 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors group"
                whileHover={{ y: -1 }}
              >
                {`0${idx + 1} // ${item}`}
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-indigo-600 dark:bg-indigo-400 transition-all duration-300 group-hover:w-full"></span>
              </motion.a>
            ))}
            <motion.a 
              href="#connect" 
              className="relative py-2 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors group animate-pulse"
              whileHover={{ y: -1 }}
            >
              05 // CONNECT
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-indigo-600 dark:bg-indigo-400 transition-all duration-300 group-hover:w-full"></span>
            </motion.a>
          </nav>

          {/* Actions Desk */}
          <div className="flex items-center gap-4">
            
            {/* Elegant Mode Toggle */}
            <motion.button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`p-2.5 rounded-full border transition-all duration-300 ${isDarkMode ? 'border-[#2d2d34] bg-[#1a1a24] text-yellow-400 hover:shadow-[0_0_15px_rgba(250,204,21,0.2)]' : 'border-neutral-300 bg-white text-neutral-800 hover:shadow-[0_0_15px_rgba(99,102,241,0.15)]'}`}
              title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
              aria-label="Toggle Theme"
              id="theme-toggle"
              whileHover={{ scale: 1.1, rotate: 15 }}
              whileTap={{ scale: 0.9 }}
            >
              {isDarkMode ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
            </motion.button>

            {/* Resume Download PDF Button */}
            <motion.button 
              onClick={downloadResumePDF}
              className="hidden sm:flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-bold tracking-wider border rounded-md transition-all duration-300 bg-transparent hover:bg-indigo-600 hover:text-white hover:border-indigo-600 border-current cursor-pointer"
              title="Download PDF Resume"
              id="download-resume-btn"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Download className="w-3.5 h-3.5" /> PDF
            </motion.button>

            {/* Mobile Menu Toggle */}
            <motion.button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 lg:hidden border border-current rounded-md hover:bg-indigo-600/10"
              aria-label="Toggle Mobile Menu"
              id="mobile-menu-btn"
              whileTap={{ scale: 0.9 }}
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </motion.button>
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className={`lg:hidden w-full border-t flex flex-col font-mono text-sm tracking-widest font-semibold p-6 gap-4 ${isDarkMode ? 'bg-[#15151a] border-[#252529]' : 'bg-[#FAF9F5] border-neutral-200'}`}
            >
              <a href="#about" onClick={() => setIsMobileMenuOpen(false)} className="py-2 border-b border-current/10 hover:text-indigo-500">01 / ABOUT</a>
              <a href="#skills" onClick={() => setIsMobileMenuOpen(false)} className="py-2 border-b border-current/10 hover:text-indigo-500">02 / SKILLS</a>
              <a href="#experience" onClick={() => setIsMobileMenuOpen(false)} className="py-2 border-b border-current/10 hover:text-indigo-500">03 / EXPERIENCE</a>
              <a href="#projects" onClick={() => setIsMobileMenuOpen(false)} className="py-2 border-b border-current/10 hover:text-indigo-500">04 / PROJECTS</a>
              <a href="#connect" onClick={() => setIsMobileMenuOpen(false)} className="py-2 hover:text-indigo-500">05 / CONNECT</a>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-6 py-12 relative z-10 flex flex-col gap-28">
        
        {/* SECTION 1: HERO & MAGAZINE COVER (Hero) */}
        <section id="home" className="grid grid-cols-1 lg:grid-cols-12 gap-12 pt-6 items-center">
          
          {/* Main Typography Header Left */}
          <motion.div 
            className="lg:col-span-8 flex flex-col justify-center gap-6"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ type: "spring", stiffness: 100, damping: 20 }}
          >
            <div className="flex items-center gap-3">
              <span className="h-[2px] w-12 bg-indigo-600 dark:bg-indigo-400"></span>
              <span className="text-xs font-mono font-black tracking-[0.4em] uppercase text-indigo-600 dark:text-indigo-400">
                B.Tech Computer Science Engineering
              </span>
            </div>

            <div className="space-y-4">
              <h1 className="text-5xl sm:text-7xl lg:text-9xl font-serif tracking-tighter leading-none font-black uppercase text-transparent bg-clip-text bg-gradient-to-r from-neutral-900 via-indigo-950 to-neutral-900 dark:from-white dark:via-indigo-200 dark:to-white">
                BODDU<br/>
                NAVYA
              </h1>
              
              <div className="flex flex-wrap gap-4 items-center">
                <span className="text-xs font-mono font-black tracking-widest uppercase border border-indigo-600 px-3 py-1 bg-indigo-600 text-white rounded">
                  SDE Candidate
                </span>
                <span className="text-sm font-mono font-bold tracking-widest uppercase opacity-75 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Python
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span> React
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span> AWS Cloud
                </span>
              </div>
            </div>

            <p className="text-lg font-serif italic max-w-2xl leading-relaxed opacity-95 border-l-4 border-indigo-600 pl-4 text-neutral-800 dark:text-neutral-200">
              "{personalInfo.objective}"
            </p>

            {/* Quick Metrics Editorial Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-current/10 mt-4">
              <div className="flex flex-col p-4 border border-current/10 bg-indigo-600/[0.03] rounded-lg hover:border-indigo-500/30 transition-all">
                <span className="text-[10px] font-mono uppercase tracking-wider opacity-60">CGPA Achieved</span>
                <span className="text-2xl font-serif font-black mt-1 text-indigo-600 dark:text-indigo-400">7.96 / 10</span>
              </div>
              <div className="flex flex-col p-4 border border-current/10 bg-emerald-600/[0.03] rounded-lg hover:border-emerald-500/30 transition-all">
                <span className="text-[10px] font-mono uppercase tracking-wider opacity-60">B.Tech Year</span>
                <span className="text-2xl font-serif font-black mt-1 text-emerald-600 dark:text-emerald-400">2023 - 2027</span>
              </div>
              <div className="flex flex-col p-4 border border-current/10 bg-amber-600/[0.03] rounded-lg hover:border-amber-500/30 transition-all">
                <span className="text-[10px] font-mono uppercase tracking-wider opacity-60">Internships</span>
                <span className="text-2xl font-serif font-black mt-1 text-amber-600 dark:text-amber-400">4 Completed</span>
              </div>
              <div className="flex flex-col p-4 border border-indigo-600/20 bg-indigo-600/5 rounded-lg">
                <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-600 dark:text-indigo-400 font-bold">Status</span>
                <span className="text-xs font-mono font-black text-emerald-600 dark:text-emerald-400 mt-2.5 uppercase tracking-widest flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                  Open to Hire
                </span>
              </div>
            </div>
          </motion.div>

          {/* Elegant Cover Profile Right */}
          <motion.div 
            className="lg:col-span-4 flex flex-col justify-end gap-6 h-full"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ type: "spring", stiffness: 100, damping: 20, delay: 0.1 }}
          >
            <div className={`border p-4 relative group transition-all duration-500 overflow-hidden rounded-xl ${isDarkMode ? 'border-neutral-800 bg-[#16161c] hover:shadow-[0_20px_50px_rgba(99,102,241,0.15)]' : 'border-neutral-200 bg-white hover:shadow-[0_20px_50px_rgba(99,102,241,0.08)]'}`}>
              
              {/* Image Container with precise 3:4 Aspect Ratio */}
              <div className="aspect-[3/4] w-full bg-[#E8E6E1] dark:bg-neutral-800 border border-current/10 relative overflow-hidden flex items-center justify-center rounded-lg">
                {(!useMonogram && !imgError) ? (
                  <img 
                    src={PROFILE_PHOTO_URL} 
                    alt="Boddu Navya" 
                    referrerPolicy="no-referrer"
                    onError={() => setImgError(true)}
                    className="object-cover w-full h-full transition-all duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col justify-between p-6 bg-gradient-to-br from-[#fbfbfa] via-[#f5f4ef] to-[#e8e6e1] dark:from-neutral-900 dark:via-neutral-950 dark:to-neutral-900 text-current transition-colors duration-500 select-none">
                    <div className="flex justify-between items-start">
                      <span className="text-[10px] font-mono tracking-widest opacity-40 uppercase">Editorial ID</span>
                      <span className="text-[10px] font-mono tracking-widest opacity-40">BN-2026</span>
                    </div>
                    
                    <div className="my-auto flex flex-col items-center justify-center text-center">
                      <span className="text-7xl font-serif font-black italic tracking-tighter text-indigo-600 dark:text-indigo-400">
                        BN
                      </span>
                      <span className="text-xs font-mono uppercase tracking-[0.2em] opacity-60 mt-4 font-bold">
                        Boddu Navya
                      </span>
                      <span className="text-[10px] font-mono uppercase tracking-wider opacity-40 mt-1">
                        SDE & Cloud Engineer
                      </span>
                    </div>

                    <div className="flex justify-between items-end border-t border-current/5 pt-4">
                      <span className="text-[8px] font-mono tracking-widest uppercase opacity-30">CSE Specialization</span>
                      <span className="text-[8px] font-mono tracking-widest uppercase opacity-30">Kakinada, IN</span>
                    </div>
                  </div>
                )}
                
                {/* Decorative absolute element */}
                <div className="absolute top-3 right-3 bg-indigo-600 text-white text-[8px] font-mono uppercase tracking-widest px-2.5 py-1 rounded shadow-lg font-black">
                  {(!useMonogram && !imgError) ? "Verified Headshot" : "Minimalist Monogram"}
                </div>
              </div>

              {/* Interactive toggle & upload tip */}
              <div className="mt-2.5 flex justify-between items-center px-1">
                <button
                  onClick={() => setUseMonogram(!useMonogram)}
                  className="text-[10px] font-mono font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  {useMonogram ? "✦ Show Photo Option" : "✦ Show Monogram"}
                </button>
                <span className="text-[9px] font-mono opacity-40 italic">
                  Drag & drop your real photo to src/assets/images!
                </span>
              </div>

              {/* Status Box Overlay */}
              <div className={`mt-4 p-4 border transition-colors duration-300 rounded-lg ${isDarkMode ? 'bg-neutral-900/90 border-neutral-800' : 'bg-[#FAF9F5]/90 border-neutral-200'}`}>
                <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400 block mb-1">
                  CURRENT FOCUS
                </span>
                <p className="text-xs font-semibold leading-relaxed">
                  Engineering dynamic responsive systems and mastering cloud automation pipelines.
                </p>
              </div>

              {/* Profile Social List */}
              <div className="mt-4 flex flex-col gap-1.5 font-mono text-xs">
                <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400 block mb-1">
                  DIGITAL INDEX
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <motion.a 
                    href={personalInfo.linkedin} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="flex items-center gap-1.5 p-2 border border-current/10 hover:bg-indigo-600 hover:text-white rounded-lg transition-all"
                    whileHover={{ scale: 1.02 }}
                  >
                    <Linkedin className="w-3.5 h-3.5" /> LinkedIn
                  </motion.a>
                  <motion.a 
                    href={personalInfo.github} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="flex items-center gap-1.5 p-2 border border-current/10 hover:bg-neutral-900 hover:text-white rounded-lg transition-all"
                    whileHover={{ scale: 1.02 }}
                  >
                    <Github className="w-3.5 h-3.5" /> GitHub
                  </motion.a>
                  <motion.a 
                    href={personalInfo.leetcode} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="flex items-center gap-1.5 p-2 border border-current/10 hover:bg-orange-500 hover:text-white rounded-lg transition-all"
                    whileHover={{ scale: 1.02 }}
                  >
                    <Code className="w-3.5 h-3.5" /> LeetCode
                  </motion.a>
                  <motion.a 
                    href={personalInfo.codechef} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="flex items-center gap-1.5 p-2 border border-current/10 hover:bg-[#5b4636] hover:text-white rounded-lg transition-all"
                    whileHover={{ scale: 1.02 }}
                  >
                    <Award className="w-3.5 h-3.5" /> CodeChef
                  </motion.a>
                </div>
                <motion.a 
                  href={personalInfo.hackerrank} 
                  target="_blank" 
                  rel="noreferrer" 
                  className="flex items-center justify-center gap-1.5 p-2 border border-current/10 hover:bg-emerald-500 hover:text-white rounded-lg transition-all text-center"
                  whileHover={{ scale: 1.02 }}
                >
                  <Terminal className="w-3.5 h-3.5" /> HackerRank Profile
                </motion.a>
              </div>
            </div>
          </motion.div>
        </section>

        {/* SECTION 2: BIOGRAPHY & ACADEMICS (About) */}
        <motion.section 
          id="about" 
          className="border-t border-neutral-200 dark:border-neutral-800 pt-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* Title Column */}
            <div className="lg:col-span-4">
              <span className="text-xs font-mono font-extrabold tracking-[0.3em] uppercase text-indigo-600 dark:text-indigo-400 block mb-2">01 // PROFILE</span>
              <h2 className="text-3xl sm:text-4xl font-serif font-black tracking-tight leading-none uppercase italic">
                Academics &<br/>Core Objectives
              </h2>
              <p className="text-sm font-mono tracking-widest uppercase opacity-75 mt-4">Kakinada, AP, India</p>
              
              <div className="mt-8 space-y-3">
                <motion.a 
                  href={`mailto:${personalInfo.email}`}
                  className="flex items-center gap-3 text-xs font-mono hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  id="email-link"
                  whileHover={{ x: 3 }}
                >
                  <Mail className="w-4 h-4 text-indigo-600 dark:text-indigo-400" /> {personalInfo.email}
                </motion.a>
                <motion.a 
                  href={`tel:${personalInfo.phone}`}
                  className="flex items-center gap-3 text-xs font-mono hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  id="phone-link"
                  whileHover={{ x: 3 }}
                >
                  <Phone className="w-4 h-4 text-indigo-600 dark:text-indigo-400" /> {personalInfo.phone}
                </motion.a>
                <div className="flex items-center gap-3 text-xs font-mono">
                  <MapPin className="w-4 h-4 text-indigo-600 dark:text-indigo-400" /> {personalInfo.location}
                </div>
                
                {/* Social Badges */}
                <div className="flex gap-4 pt-4">
                  <motion.a 
                    href={personalInfo.linkedin} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="p-2.5 border border-current rounded-full hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-all"
                    title="LinkedIn Profile"
                    id="linkedin-icon"
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Linkedin className="w-4 h-4" />
                  </motion.a>
                  <motion.a 
                    href={personalInfo.github} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="p-2.5 border border-current rounded-full hover:bg-[#121212] hover:text-white dark:hover:bg-white dark:hover:text-black hover:border-transparent transition-all"
                    title="GitHub Profile"
                    id="github-icon"
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Github className="w-4 h-4" />
                  </motion.a>
                </div>
              </div>
            </div>

            {/* Academic Content Columns */}
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-8">
              
              {/* Detailed Narrative */}
              <div className="space-y-6">
                <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400 border-b border-current/10 pb-2">Narrative</h3>
                <p className="text-sm leading-relaxed font-sans text-neutral-800 dark:text-neutral-200">
                  As an engineering student at Aditya College, I discovered my deep passion for crafting modular code systems and cloud-based deployments early in my studies. I enjoy bridging complex algorithms with beautiful web layouts.
                </p>
                <p className="text-sm leading-relaxed font-sans text-neutral-800 dark:text-neutral-200">
                  Through rigorous coursework and hands-on internships, I have cultivated proficiency across both standard OOP structures (Java, Python) and cloud computing strategies. My work is defined by strict attention to detail, transactional database design, and mobile-first responsivity.
                </p>
                <motion.div 
                  className="p-4 bg-emerald-500/10 border-l-4 border-emerald-500 rounded-r-xl"
                  whileHover={{ scale: 1.01 }}
                >
                  <p className="text-xs font-mono font-black uppercase text-emerald-600 dark:text-emerald-400 mb-1">
                    Seeking Opportunities
                  </p>
                  <p className="text-xs font-sans">
                    Actively interviewing for Software Engineer (SDE) internships and junior engineer full-time roles starting in 2026/2027.
                  </p>
                </motion.div>
              </div>

              {/* Coursework & Education Box */}
              <div className="space-y-6">
                <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400 border-b border-current/10 pb-2">Academic Roadmap</h3>
                
                <div className={`border p-6 rounded-xl transition-all ${isDarkMode ? 'border-neutral-800 bg-[#16161c]/40 hover:bg-[#16161c]/70' : 'border-neutral-200 bg-white hover:bg-white/80'}`}>
                  <span className="text-[10px] font-mono tracking-widest text-indigo-600 dark:text-indigo-400 font-extrabold uppercase block mb-1">
                    {personalInfo.education.period}
                  </span>
                  <h4 className="text-xl font-serif font-black">{personalInfo.education.degree}</h4>
                  <p className="text-xs font-mono font-bold mt-1 opacity-75">{personalInfo.education.institution}</p>
                  
                  <div className="mt-4 flex items-center justify-between border-t border-current/10 pt-3">
                    <span className="text-xs font-mono font-bold">Cumulative CGPA:</span>
                    <span className="text-sm font-serif font-black px-3 py-1 rounded bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                      {personalInfo.education.cgpa} / 10
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-mono font-black tracking-wider uppercase opacity-50 block">Key Specialized Coursework</span>
                  <div className="flex flex-wrap gap-1.5">
                    {personalInfo.education.coursework.map((course, idx) => (
                      <motion.span 
                        key={idx}
                        className="text-[10px] font-mono px-2.5 py-1.5 rounded-md bg-indigo-600/[0.04] text-neutral-800 dark:text-neutral-200 border border-current/10 font-medium"
                        whileHover={{ scale: 1.05, backgroundColor: "rgba(99,102,241,0.08)" }}
                      >
                        {course}
                      </motion.span>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          </div>
        </motion.section>

        {/* SECTION 3: SKILLS MATRIX (Skills) */}
        <motion.section 
          id="skills" 
          className="border-t border-neutral-200 dark:border-neutral-800 pt-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="flex flex-col gap-8">
            
            {/* Header */}
            <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4 border-b border-current/10 pb-6">
              <div>
                <span className="text-xs font-mono font-extrabold tracking-[0.3em] uppercase text-indigo-600 dark:text-indigo-400 block mb-2">02 // ARCHITECTURE</span>
                <h2 className="text-3xl sm:text-4xl font-serif font-black uppercase italic">Technical Inventory</h2>
                <p className="text-xs font-mono mt-2 opacity-70">
                  *Click on a skill name to highlight connected internship experience and projects!
                </p>
              </div>

              {/* Interactive Tabs */}
              <div className="flex flex-wrap gap-2">
                {skillCategories.map((cat) => (
                  <motion.button
                    key={cat.id}
                    onClick={() => {
                      setSelectedSkillCategory(cat.id);
                      setHighlightedSkill(null);
                    }}
                    className={`px-3.5 py-2 text-xs font-mono font-extrabold tracking-wider border rounded-lg transition-all duration-300 cursor-pointer ${selectedSkillCategory === cat.id ? 'bg-indigo-600 text-white dark:bg-indigo-400 dark:text-neutral-900 border-indigo-600 dark:border-indigo-400 shadow-[0_4px_12px_rgba(99,102,241,0.25)]' : 'border-neutral-300 dark:border-neutral-800 hover:border-indigo-600 dark:hover:border-indigo-400 bg-transparent'}`}
                    id={`skill-tab-${cat.id}`}
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {cat.label}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Matrix Display */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              <AnimatePresence mode="popLayout">
                {filteredSkills.map((skill, idx) => {
                  const isActiveHighlight = highlightedSkill === skill.name;
                  return (
                    <motion.button
                      key={skill.name}
                      onClick={() => setHighlightedSkill(isActiveHighlight ? null : skill.name)}
                      className={`flex flex-col text-left p-4.5 border rounded-xl transition-all duration-300 relative group cursor-pointer ${isActiveHighlight ? 'border-indigo-600 dark:border-indigo-400 bg-indigo-600/5 ring-2 ring-indigo-600/25 shadow-lg shadow-indigo-600/10' : 'border-neutral-200 dark:border-neutral-800/80 hover:border-indigo-600/40 dark:hover:border-indigo-400/40 bg-neutral-100/5 dark:bg-neutral-800/5'}`}
                      id={`skill-card-${skill.name.toLowerCase().replace(/\s+/g, '-')}`}
                      whileHover={{ y: -4, scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ type: "spring", stiffness: 150, damping: 15 }}
                    >
                      <div className="flex justify-between items-start w-full">
                        <span className="text-[9px] font-mono tracking-widest uppercase text-indigo-600 dark:text-indigo-400 font-extrabold">
                          {skill.category}
                        </span>
                        {isActiveHighlight && (
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 dark:bg-indigo-400 animate-ping"></span>
                        )}
                      </div>
                      <span className="text-sm font-bold font-mono tracking-tight mt-3 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        {skill.name}
                      </span>
                      
                      {/* Visual Connector Count Overlay */}
                      {(skill.relatedProjects.length > 0 || skill.relatedExperience.length > 0) && (
                        <div className="absolute bottom-2.5 right-2.5 text-[8px] font-mono px-2 py-0.5 rounded bg-indigo-600/5 dark:bg-indigo-400/5 border border-indigo-500/10 opacity-60 group-hover:opacity-100 transition-opacity">
                          {skill.relatedProjects.length + skill.relatedExperience.length} links
                        </div>
                      )}
                    </motion.button>
                  );
                })}
              </AnimatePresence>
            </div>

            {/* Cross-Reference Feedback banner */}
            <AnimatePresence>
              {highlightedSkill && (
                <motion.div 
                  initial={{ opacity: 0, height: 0, y: 15 }}
                  animate={{ opacity: 1, height: 'auto', y: 0 }}
                  exit={{ opacity: 0, height: 0, y: 15 }}
                  className="p-4.5 bg-indigo-600/10 border border-indigo-600/30 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-600 text-white rounded-lg shadow-md animate-pulse">
                      <Terminal className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-mono font-black uppercase tracking-wider text-indigo-700 dark:text-indigo-300">
                        Cross-Reference Active: {highlightedSkill}
                      </h4>
                      <p className="text-xs font-sans mt-0.5 text-neutral-700 dark:text-neutral-300">
                        This technology was applied in highlighted items across the Experience and Projects sections below.
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setHighlightedSkill(null)}
                    className="text-xs font-mono font-bold px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white hover:opacity-90 rounded-lg shadow-sm transition-all"
                  >
                    Clear Highlight
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

          </div>
        </motion.section>

        {/* SECTION 4: INTERNSHIPS (Experience) */}
        <motion.section 
          id="experience" 
          className="border-t border-neutral-200 dark:border-neutral-800 pt-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* Title / Info Column */}
            <div className="lg:col-span-4 flex flex-col justify-between">
              <div>
                <span className="text-xs font-mono font-extrabold tracking-[0.3em] uppercase text-indigo-600 dark:text-indigo-400 block mb-2">03 // CHRONOLOGY</span>
                <h2 className="text-3xl sm:text-4xl font-serif font-black uppercase italic">Professional Internships</h2>
                <p className="text-sm leading-relaxed mt-4 text-neutral-700 dark:text-neutral-300">
                  During my academic path, I completed formal technical internships to build real-world software competence.
                </p>
              </div>

              {/* Vertical Tab Controls */}
              <div className="flex flex-col gap-2 mt-8 lg:mt-0">
                {internships.map((intern) => {
                  const isSelected = selectedInternshipId === intern.id;
                  const isLinked = isSkillConnectedToActiveExperience(intern.id);
                  return (
                    <motion.button
                      key={intern.id}
                      onClick={() => setSelectedInternshipId(intern.id)}
                      className={`text-left p-4.5 border rounded-xl transition-all duration-300 relative cursor-pointer ${isSelected ? 'border-indigo-600 dark:border-indigo-400 bg-indigo-600/5 shadow-md shadow-indigo-600/5' : isLinked ? 'border-dashed border-indigo-600/50 bg-indigo-500/5 ring-1 ring-indigo-500/10' : 'border-neutral-200 dark:border-neutral-800/60 hover:border-neutral-400 dark:hover:border-neutral-600 bg-transparent'}`}
                      id={`internship-tab-${intern.id}`}
                      whileHover={{ x: 4 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-mono font-extrabold text-indigo-600 dark:text-indigo-400 uppercase">{intern.period}</span>
                        {isLinked && (
                          <span className="text-[8px] font-mono bg-indigo-600 text-white px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                            Link Active
                          </span>
                        )}
                      </div>
                      <h4 className="text-base font-bold font-serif tracking-tight mt-1.5">{intern.company}</h4>
                      <p className="text-xs font-mono opacity-80 mt-0.5">{intern.role}</p>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Dynamic Content View Column */}
            <div className="lg:col-span-8">
              {(() => {
                const activeIntern = internships.find(i => i.id === selectedInternshipId) || internships[0];
                return (
                  <motion.div 
                    key={activeIntern.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4 }}
                    className={`p-6 md:p-8 border rounded-xl transition-all duration-300 h-full flex flex-col justify-between ${isDarkMode ? 'border-neutral-800 bg-[#16161c]/40 hover:shadow-[0_20px_40px_rgba(99,102,241,0.05)]' : 'border-neutral-200 bg-white hover:shadow-[0_20px_40px_rgba(99,102,241,0.03)]'}`}
                  >
                    
                    <div>
                      {/* Header Info */}
                      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 border-b border-current/10 pb-4 mb-6">
                        <div>
                          <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 dark:text-indigo-400 uppercase">
                            {activeIntern.period}
                          </span>
                          <h3 className="text-2xl font-serif font-black mt-1 uppercase tracking-tight">{activeIntern.company}</h3>
                          <p className="text-sm font-mono mt-1 opacity-85 font-bold text-indigo-600 dark:text-indigo-400">{activeIntern.role}</p>
                        </div>
                        <div className="flex items-center gap-1.5 text-xs font-mono opacity-70">
                          <MapPin className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" /> {activeIntern.location}
                        </div>
                      </div>

                      {/* Work Bullets */}
                      <div className="space-y-4">
                        <span className="text-xs font-mono font-bold tracking-wider opacity-50 block">Key Contributions</span>
                        <ul className="space-y-3.5 pl-5 list-disc text-indigo-600 dark:text-indigo-400">
                          {activeIntern.description.map((bullet, idx) => (
                            <li key={idx} className="text-sm leading-relaxed text-neutral-800 dark:text-neutral-200 pl-1.5">
                              {bullet}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="mt-8 pt-6 border-t border-current/10 space-y-4">
                      
                      {/* Achievements Highlight */}
                      <div className="p-4.5 bg-emerald-500/15 border-l-4 border-emerald-500 rounded-r-xl">
                        <span className="text-[9px] font-mono font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400 block mb-1">
                          Core Milestone Accomplished
                        </span>
                        <p className="text-xs italic font-medium leading-relaxed text-neutral-800 dark:text-neutral-200">
                          "{activeIntern.achievement}"
                        </p>
                      </div>

                      {/* Tech Used */}
                      <div>
                        <span className="text-xs font-mono font-bold tracking-wider opacity-50 block mb-2">Technologies Executed</span>
                        <div className="flex flex-wrap gap-1.5">
                          {activeIntern.technologies.map((tech, idx) => {
                            const isLinkedSkill = highlightedSkill === tech || (tech.includes('AWS') && highlightedSkill?.includes('AWS'));
                            return (
                              <motion.span 
                                key={idx}
                                className={`text-[10px] font-mono px-2.5 py-1 rounded-md transition-all ${isLinkedSkill ? 'bg-indigo-600 text-white border-indigo-600 font-extrabold ring-2 ring-indigo-600/25 shadow-md shadow-indigo-600/10' : 'bg-indigo-600/5 dark:bg-indigo-400/5 border border-current/10 font-bold'}`}
                                whileHover={{ scale: 1.05 }}
                              >
                                {tech}
                              </motion.span>
                            );
                          })}
                        </div>
                      </div>

                    </div>

                  </motion.div>
                );
              })()}
            </div>

          </div>
        </motion.section>

        {/* SECTION 5: PROJECTS SHOWCASE (Projects) */}
        <motion.section 
          id="projects" 
          className="border-t border-neutral-200 dark:border-neutral-800 pt-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="flex flex-col gap-8">
            
            {/* Header with Carousel Navigation */}
            <div className="border-b border-current/10 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-extrabold tracking-[0.3em] uppercase text-indigo-600 dark:text-indigo-400 block mb-2">04 // ARCHITECTURE</span>
                <h2 className="text-3xl sm:text-4xl font-serif font-black uppercase italic">Technical Projects</h2>
                <p className="text-sm mt-1 text-neutral-700 dark:text-neutral-300">
                  A selection of self-authored applications demonstrating core stack competency and deployment standards.
                </p>
              </div>

              {/* Slider Left and Right Controls */}
              <div className="flex gap-3.5 items-center">
                <span className="text-[10px] font-mono tracking-widest uppercase opacity-60">
                  {startIndex + 1} – {Math.min(startIndex + visibleProjectsCount, projects.length)} of {projects.length}
                </span>
                <div className="flex gap-2">
                  <motion.button
                    onClick={handlePrevProject}
                    className={`p-2.5 rounded-full border transition-all cursor-pointer ${isDarkMode ? 'border-neutral-800 hover:bg-neutral-800 text-white' : 'border-neutral-200 hover:bg-neutral-100 text-black'}`}
                    aria-label="Previous Projects"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </motion.button>
                  <motion.button
                    onClick={handleNextProject}
                    className={`p-2.5 rounded-full border transition-all cursor-pointer ${isDarkMode ? 'border-neutral-800 hover:bg-neutral-800 text-white' : 'border-neutral-200 hover:bg-neutral-100 text-black'}`}
                    aria-label="Next Projects"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </div>
              </div>
            </div>

            {/* Sliced Projects Slider Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <AnimatePresence mode="wait">
                {projects.slice(startIndex, startIndex + visibleProjectsCount).map((proj) => {
                  const isLinked = isSkillConnectedToActiveProject(proj.id);
                  return (
                    <motion.div
                      key={proj.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                      className={`border rounded-xl p-6 flex flex-col justify-between transition-all duration-300 relative group cursor-pointer ${isLinked ? 'border-indigo-600 dark:border-indigo-400 bg-indigo-600/5 ring-2 ring-indigo-600/10 shadow-lg shadow-indigo-600/5' : 'border-neutral-200 dark:border-neutral-800 bg-neutral-100/5 dark:bg-neutral-800/5'}`}
                      id={`project-card-${proj.id}`}
                      whileHover={{ y: -8, scale: 1.01 }}
                    >
                      <div>
                        {/* Image Thumbnail with AI Generated Project Preview */}
                        <div className="w-full aspect-[16/9] mb-4 bg-neutral-900 text-neutral-100 flex items-center justify-center border border-current/10 relative overflow-hidden rounded-lg group-hover:shadow-md transition-shadow">
                          {proj.previewImage ? (
                            <img 
                              src={proj.previewImage} 
                              alt={proj.title} 
                              referrerPolicy="no-referrer"
                              className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"
                            />
                          ) : (
                            <span className="font-serif italic text-2xl font-light">{proj.illustration}</span>
                          )}
                          
                          {/* Decorative editorial absolute stats */}
                          <span className="absolute bottom-2.5 left-2.5 text-[8px] font-mono tracking-widest text-white bg-black/60 px-2.5 py-1 rounded backdrop-blur-sm">
                            {proj.metrics.split('•')[0]}
                          </span>
                          
                          {isLinked && (
                            <div className="absolute top-2.5 right-2.5 bg-indigo-600 text-white text-[9px] font-mono tracking-wider px-2.5 py-1 rounded uppercase font-black animate-pulse shadow-lg">
                              Linked Skill
                            </div>
                          )}
                        </div>

                        <div className="flex justify-between items-start gap-2">
                          <span className="text-[10px] font-mono tracking-widest uppercase text-indigo-600 dark:text-indigo-400 font-extrabold">
                            {proj.category}
                          </span>
                        </div>

                        <h3 className="text-xl font-serif font-black tracking-tight mt-2 uppercase">
                          {proj.title}
                        </h3>
                        <p className="text-xs font-mono opacity-85 mt-1 font-bold text-indigo-600 dark:text-indigo-400">
                          {proj.subtitle}
                        </p>
                        
                        <p className="text-sm mt-3 leading-relaxed text-neutral-700 dark:text-neutral-300">
                          {proj.description}
                        </p>
                      </div>

                      <div className="mt-6 pt-4 border-t border-current/10">
                        
                        {/* Tech Tags */}
                        <div className="flex flex-wrap gap-1.5 mb-4">
                          {proj.technologies.slice(0, 4).map((tech, idx) => {
                            const isActive = highlightedSkill === tech;
                            return (
                              <span 
                                key={idx}
                                className={`text-[9px] font-mono px-2 py-0.5 rounded-md ${isActive ? 'bg-indigo-600 text-white border-indigo-600 font-extrabold ring-2 ring-indigo-600/25' : 'bg-indigo-600/5 dark:bg-indigo-400/5 border border-current/10 font-bold'}`}
                              >
                                {tech}
                              </span>
                            );
                          })}
                          {proj.technologies.length > 4 && (
                            <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-current/5 opacity-50">
                              +{proj.technologies.length - 4} more
                            </span>
                          )}
                        </div>

                        {/* Modal Trigger & External Links */}
                        <div className="flex justify-between items-center w-full">
                          <motion.button
                            onClick={() => setSelectedProjectId(proj.id)}
                            className="text-xs font-mono font-bold tracking-widest uppercase border-b-2 border-indigo-600 dark:border-indigo-400 pb-0.5 hover:opacity-75 transition-opacity inline-flex items-center gap-1 cursor-pointer"
                            id={`btn-details-${proj.id}`}
                            whileHover={{ x: 3 }}
                          >
                            Explore Specs <ChevronRight className="w-3.5 h-3.5" />
                          </motion.button>

                          <div className="flex gap-3">
                            <motion.a 
                              href={proj.github} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="p-2 border border-current/10 rounded-full hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-all"
                              title="View GitHub Repository"
                              id={`github-link-${proj.id}`}
                              whileHover={{ scale: 1.1, y: -1 }}
                            >
                              <Github className="w-4 h-4" />
                            </motion.a>
                          </div>
                        </div>

                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>

          </div>
        </motion.section>

        {/* SECTION 6: CONNECT SHEET & OFFLINE CRM (Connect) */}
        <motion.section 
          id="connect" 
          className="border-t border-neutral-200 dark:border-neutral-800 pt-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* CRM Title Left */}
            <div className="lg:col-span-4">
              <span className="text-xs font-mono font-extrabold tracking-[0.3em] uppercase text-indigo-600 dark:text-indigo-400 block mb-2">05 // CONNECT</span>
              <h2 className="text-3xl sm:text-4xl font-serif font-black uppercase italic">Inquiry CRM Ledger</h2>
              <p className="text-sm mt-4 leading-relaxed text-neutral-700 dark:text-neutral-300">
                Submit an interview invitation, collaboration proposal, or general feedback. Message logs are registered locally on your client machine's CRM history panel.
              </p>

              {/* Direct Card info */}
              <div className={`mt-8 border p-5 rounded-xl transition-all ${isDarkMode ? 'border-neutral-800 bg-[#16161c]/40 hover:bg-[#16161c]/70' : 'border-neutral-200 bg-white hover:bg-white/80'}`}>
                <h4 className="text-xs font-mono font-bold uppercase tracking-wider mb-3 text-indigo-600 dark:text-indigo-400">Permanent Contact Card</h4>
                <div className="space-y-3 font-sans text-sm">
                  <p className="flex justify-between border-b border-current/5 pb-2">
                    <span className="opacity-60">Primary Email</span>
                    <a href={`mailto:${personalInfo.email}`} className="font-mono hover:text-indigo-600 dark:hover:text-indigo-400 underline transition-colors">{personalInfo.email}</a>
                  </p>
                  <p className="flex justify-between border-b border-current/5 pb-2">
                    <span className="opacity-60">Call Directly</span>
                    <span className="font-mono font-semibold">{personalInfo.phone}</span>
                  </p>
                  <p className="flex justify-between">
                    <span className="opacity-60">Location</span>
                    <span className="font-semibold">{personalInfo.location}</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Input & Submitted History Right */}
            <div className="lg:col-span-8 flex flex-col gap-10">
              
              {/* Form panel */}
              <div className={`p-6 md:p-8 border rounded-xl shadow-md ${isDarkMode ? 'border-neutral-800 bg-[#16161c]/50' : 'border-neutral-200 bg-white'}`}>
                <h3 className="text-lg font-serif font-black uppercase mb-6 tracking-tight text-indigo-600 dark:text-indigo-400">Connect Form</h3>
                
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label htmlFor="name-input" className="text-xs font-mono font-bold tracking-wide uppercase opacity-70">Your Name *</label>
                      <input
                        type="text"
                        id="name-input"
                        required
                        value={contactForm.name}
                        onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                        className="w-full px-4 py-2.5 border border-neutral-200 dark:border-neutral-800 bg-transparent rounded-lg focus:border-indigo-600 dark:focus:border-indigo-400 outline-none transition-all"
                        placeholder="Enter your name"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label htmlFor="email-input" className="text-xs font-mono font-bold tracking-wide uppercase opacity-70">Email Address *</label>
                      <input
                        type="email"
                        id="email-input"
                        required
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        className="w-full px-4 py-2.5 border border-neutral-200 dark:border-neutral-800 bg-transparent rounded-lg focus:border-indigo-600 dark:focus:border-indigo-400 outline-none transition-all"
                        placeholder="recruiter@company.com"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="company-input" className="text-xs font-mono font-bold tracking-wide uppercase opacity-70">Company / Organization</label>
                    <input
                      type="text"
                      id="company-input"
                      value={contactForm.company}
                      onChange={(e) => setContactForm({ ...contactForm, company: e.target.value })}
                      className="w-full px-4 py-2.5 border border-neutral-200 dark:border-neutral-800 bg-transparent rounded-lg focus:border-indigo-600 dark:focus:border-indigo-400 outline-none transition-all"
                      placeholder="Tech Enterprise Corp"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="message-input" className="text-xs font-mono font-bold tracking-wide uppercase opacity-70">Detailed Message *</label>
                    <textarea
                      id="message-input"
                      required
                      rows={4}
                      value={contactForm.message}
                      onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                      className="w-full px-4 py-2.5 border border-neutral-200 dark:border-neutral-800 bg-transparent rounded-lg focus:border-indigo-600 dark:focus:border-indigo-400 outline-none transition-all"
                      placeholder="Enter your message here..."
                    />
                  </div>

                  <motion.button
                    type="submit"
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-mono text-xs font-black tracking-widest uppercase rounded-lg shadow-md cursor-pointer transition-all"
                    id="form-submit-btn"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    REGISTER TO LOCAL CRM
                  </motion.button>

                  {formSubmitted && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 rounded-lg text-xs font-mono flex items-center gap-2"
                    >
                      <CheckCircle className="w-4 h-4 flex-shrink-0 animate-bounce" />
                      <span>Message successfully written to client localStorage ledger history!</span>
                    </motion.div>
                  )}
                </form>
              </div>

              {/* Local CRM History View */}
              {savedMessages.length > 0 && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b border-current/10 pb-2">
                    <h3 className="text-xs font-mono font-black uppercase tracking-widest opacity-60">
                      Your Client Message Logs ({savedMessages.length})
                    </h3>
                    <button 
                      onClick={clearMessages}
                      className="text-[10px] font-mono text-red-500 hover:underline cursor-pointer"
                      id="clear-crm-btn"
                    >
                      Clear CRM Cache
                    </button>
                  </div>

                  <div className="space-y-3 max-h-[250px] overflow-y-auto pr-2">
                    {savedMessages.map((msg) => (
                      <div 
                        key={msg.id}
                        className="p-4 border border-neutral-200 dark:border-neutral-800 bg-[#FAF9F5] dark:bg-neutral-900 rounded-xl space-y-1.5 text-xs"
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="font-bold">{msg.name}</span>
                            <span className="opacity-50"> • {msg.company}</span>
                          </div>
                          <span className="text-[10px] opacity-40 font-mono">{msg.date}</span>
                        </div>
                        <p className="font-mono opacity-70 break-all">{msg.email}</p>
                        <p className="italic bg-current/5 p-2 rounded text-neutral-800 dark:text-neutral-200">
                          "{msg.message}"
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </div>
        </motion.section>

      </main>

      {/* FOOTER DESK */}
      <footer className="mt-24 border-t border-current/20 py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center text-xs font-mono gap-4">
          
          <div className="flex flex-col gap-2">
            <span className="text-[10px] uppercase opacity-40 font-black tracking-widest">OWNER & LICENSING</span>
            <span className="font-serif italic text-sm font-extrabold">Boddu Navya</span>
            <p className="opacity-60 leading-relaxed mt-1">
              B.Tech Computer Science Engineering student.<br/>
              © 2026 Boddu Navya. All Rights Reserved.
            </p>
          </div>

        </div>
      </footer>

      {/* PROJECT DETAILED MODAL / SPEC DRAWER */}
      <AnimatePresence>
        {selectedProjectId && (() => {
          const proj = projects.find(p => p.id === selectedProjectId);
          if (!proj) return null;
          return (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-[#121212]/80 backdrop-blur-sm z-50 flex justify-end"
              onClick={() => setSelectedProjectId(null)}
            >
              
              {/* Drawer container */}
              <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 30, stiffness: 300 }}
                className={`w-full max-w-2xl h-full p-6 md:p-8 overflow-y-auto flex flex-col justify-between relative shadow-2xl ${isDarkMode ? 'bg-[#14141c] text-[#F9F8F6]' : 'bg-[#FAF9F5] text-[#121212] border-l border-neutral-200 dark:border-neutral-800'}`}
                onClick={(e) => e.stopPropagation()}
              >
                
                <div>
                  {/* Close handle & Metadata */}
                  <div className="flex justify-between items-center border-b border-current/10 pb-4 mb-6">
                    <span className="text-[10px] font-mono tracking-widest uppercase opacity-60">
                      PROJECT ARCHITECTURE BREAKDOWN
                    </span>
                    <button 
                      onClick={() => setSelectedProjectId(null)}
                      className="p-2 border border-neutral-300 dark:border-neutral-700 rounded-full hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors cursor-pointer flex items-center justify-center"
                      title="Close spec panel"
                      id="close-spec-btn"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Main Identity */}
                  <span className="text-xs font-mono font-bold tracking-widest text-indigo-600 dark:text-indigo-400 uppercase">
                    {proj.category}
                  </span>
                  <h3 className="text-3xl font-serif font-black uppercase mt-1 leading-tight tracking-tight text-neutral-900 dark:text-neutral-50">
                    {proj.title}
                  </h3>
                  <p className="text-sm font-mono mt-1 text-indigo-600 dark:text-indigo-400 font-semibold">{proj.subtitle}</p>

                  {/* Comprehensive specs */}
                  <div className="mt-8 space-y-6">
                    
                    {/* Summary */}
                    <div className="space-y-2">
                      <span className="text-xs font-mono font-black uppercase tracking-wider opacity-50 block border-b border-current/5 pb-1">Overview</span>
                      <p className="text-sm leading-relaxed font-sans text-neutral-700 dark:text-neutral-300">
                        {proj.longDescription}
                      </p>
                    </div>

                    {/* Highlights Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                      
                      {/* Features list */}
                      <div className="space-y-3">
                        <span className="text-xs font-mono font-black uppercase tracking-wider opacity-50 block border-b border-current/5 pb-1">
                          Dynamic Features
                        </span>
                        <ul className="space-y-2.5">
                          {proj.keyFeatures.map((feat, idx) => (
                            <li key={idx} className="text-xs font-sans leading-relaxed flex items-start gap-2 text-neutral-700 dark:text-neutral-300">
                              <span className="text-emerald-500 mt-0.5 font-bold">✔</span>
                              <span>{feat}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Architectural block */}
                      <div className="space-y-3">
                        <span className="text-xs font-mono font-black uppercase tracking-wider opacity-50 block border-b border-current/5 pb-1">
                          System Architecture
                        </span>
                        <ul className="space-y-2.5">
                          {proj.architecture.map((arch, idx) => (
                            <li key={idx} className="text-xs font-mono leading-relaxed flex items-start gap-2 opacity-85 text-neutral-700 dark:text-neutral-300">
                              <span className="text-indigo-600 dark:text-indigo-400 font-extrabold">•</span>
                              <span>{arch}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                    </div>

                  </div>
                </div>

                {/* Bottom Drawer Actions */}
                <div className="mt-12 pt-6 border-t border-current/10 flex flex-col sm:flex-row justify-between items-center gap-4">
                  
                  {/* Stats */}
                  <div className="flex flex-col text-left">
                    <span className="text-[9px] font-mono uppercase opacity-40">System Benchmarks</span>
                    <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400">{proj.metrics}</span>
                  </div>

                  {/* Core Buttons */}
                  <div className="flex gap-3 w-full sm:w-auto">
                    <motion.a 
                      href={proj.github}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 sm:flex-none text-center px-4 py-2 text-xs font-mono font-bold tracking-widest uppercase border border-neutral-300 dark:border-neutral-700 rounded-lg hover:border-indigo-600 dark:hover:border-indigo-400 transition-all"
                      id={`modal-github-link`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      Source Code
                    </motion.a>
                    <motion.button 
                      onClick={() => setSelectedProjectId(null)}
                      className="flex-1 sm:flex-none text-center px-4 py-3 text-xs font-mono font-bold tracking-widest uppercase bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-md cursor-pointer transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      Return to Grid
                    </motion.button>
                  </div>

                </div>

              </motion.div>

            </motion.div>
          );
        })()}
      </AnimatePresence>

    </div>
  );
}
